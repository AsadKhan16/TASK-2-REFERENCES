import sqlite3

conn = sqlite3.connect('students.db')
conn = sqlite3.connect('users.db')
print("Opened database scuccesfully");

conn.execute('CREATE TABLE  if NOT EXISTS students(name TEXT, addr TEXT, city TEXT)')
conn.execute('CREATE TABLE if NOT EXISTS users (id INTEGER PRIMARY KEY , email TEXT , password TEXT)')
#print("Table created Succesfully");

conn.close

#python -m flask --debug run 
from flask import Flask , render_template ,url_for , request ,redirect

app = Flask(__name__)




@app.route("/enternew")
def new_student():
    return render_template("student.html")



@app.route('/addrec' , methods = ['POST','GET'])
def addrec():
    if request.method == 'POST':
        try:
            name = request.form['name']
            addr = request.form['add']
            city = request.form['city']

            with sqlite3.connect("students.db") as con:
                cur = con.cursor()
                cur.execute("INSERT INTO students (name,addr,city) VALUES (?,?,?)",(name,addr,city) )
                con.commit
                msg = "Record successfully added"

        

        except:
            con.rollback()
            msg = "error in insert operation"
        finally:
            con.close()
            return render_template("result.html", msg = msg)
        


@app.route("/liststudents")
def liststudents():
    con = sqlite3.connect("students.db")
    con.row_factory = sqlite3.Row

    cur = con.cursor()
    cur.execute("select * from students")

    rows = cur.fetchall();
    return render_template("studentlist.html",rows=rows)


@app.route("/")
def home():
    conn = sqlite3.connect('students.db')
    conn.execute('CREATE TABLE if NOT EXISTS students (name TEXT, addr TEXT, city TEXT)')
    conn.execute('CREATE TABLE if NOT EXISTS users (id INTEGER PRIMARY KEY , email TEXT , password TEXT)')
    
    conn.close

    return render_template('home.html')


@app.route("/delete_all")
def delete_all():
    con = sqlite3.connect("students.db")
    con.execute ("DROP TABLE students")
    con.execute ("VACUUM")
    con.close
    return redirect(url_for("home")) 

@app.route("/search_page")
def search_page():
    return render_template("search.html")


@app.route("/search_student_name" , methods = ["POST"  , "GET"])
def search_student_name():
    con = sqlite3.connect("students.db")
    cursor = con.cursor()
    student_name = request.form['search_name']
    cursor.execute("SELECT * FROM students WHERE name LIKE (?)",(student_name,))
    name_data = cursor.fetchall()
    con.close
    return render_template ("name_search_result.html" , student_name = student_name , name_data = name_data)

    
@app.route("/signup" , methods = ["POST" , "GET"] )
def signup():
    return render_template("signup.html")
    
@app.route("/add_user" , methods = ["POST" , "GET"])
def add_user():
    con = sqlite3.connect("users.db")
    cur = con.cursor()

    email  = request.form['email']
    password  = request.form['password']

    cur.execute("INSERT INTO users (email,password) VALUES (?,?)",(email,password) )
    con.commit
    con.close
    return render_template("confirm_signup.html" , email = email , password = password)




    





   



if __name__ == '__main__':
    app.run(debug=True)