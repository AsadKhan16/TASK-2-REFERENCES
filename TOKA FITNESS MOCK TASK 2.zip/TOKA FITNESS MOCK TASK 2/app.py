import sqlite3
conn = sqlite3.connect("users.db")
print("Opened database")
conn.execute('CREATE TABLE if NOT EXISTS users (id INTEGER PRIMARY KEY , email TEXT , password TEXT)')
print("Created users database if not present")



from flask import Flask , url_for , render_template , request ,redirect
app = Flask(__name__)

#HOME PAGE
global login_status
login_status = False

global user
user = ""

from app import login_status , user

print (login_status)

@app.route("/"  ,  methods = ['POST' , 'GET'])
def home():
    global login_status
    global user
    
    return render_template ("home.html" , login_status = login_status , user = user)

#SIGN UP PAGE AND PROCESS
@app.route("/signup" , methods = ['POST' , 'GET'])
def signup_page():
    return render_template ("signup.html")

@app.route("/add_user" ,  methods = ['POST' , 'GET'])
def add_user():
    con = sqlite3.connect("users.db")
    cur = con.cursor()

    email_signup = request.form ["email_signup" ]
    password_signup = request.form ["password_signup"]

    cur.execute("INSERT INTO users (email,password) VALUES (?,?)" ,(email_signup,password_signup))
    con.commit()
    con.close()

    return render_template ("confirm_signup.html" , email_signup = email_signup , password = password_signup)

#LOGIN PAGE AND PROCESS
@app.route("/login_page" , methods = ['POST' , 'GET'])
def login_page():
    return render_template("login_page.html")

@app.route("/login" , methods = ['POST' , 'GET'])
def login():
    global login_status
    global user
    con = sqlite3.connect("users.db")
    cur = con.cursor()

    email_login = request.form["email_login"]
    password_login = request.form["password_login"]

    cur.execute("SELECT * FROM users WHERE email = (?) AND password = (?)",(email_login,password_login))
    details = cur.fetchall()
    if details:
        login_status = True
        user = email_login
        return render_template ("home.html" , details = details , user = user , login_status = login_status)
    else:
        return render_template ("Login_fail.html")
    



@app.route("/logout")
def logout():
    global user
    user = ""
    global login_status
    login_status = False
    return render_template("home.html")


@app.route("/workout_tracker" , methods = ['POST' , 'GET'])
def workout_tracker():
    global login_status
    global user
    if login_status == True:
        
        return render_template("workout_tracker.html" , user = user)
    else:
        return render_template("no_login.html")



if __name__ == ("__main__"):
    app.run(debug=True)